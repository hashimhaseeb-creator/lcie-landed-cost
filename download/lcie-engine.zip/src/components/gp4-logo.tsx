import * as React from 'react';

/**
 * Green G(P)⁴™ logo — the official ring mark (four-arc ring = Plan · Procure ·
 * Produce · Provide, with the "G(P)4™" wordmark and a faint world map).
 * Renders the brand PNG. `size` is the rendered pixel size; the mark sits in a
 * rounded container so it looks clean on any background.
 */
export function Gp4Logo({
  size = 48,
  className,
}: {
  size?: number;
  className?: string;
}) {
  return (
    <img
      src="/gp4-logo.png"
      alt="Green G(P)4 trademark logo"
      width={size}
      height={size}
      className={`rounded-full object-cover ${className ?? ''}`}
      style={{ width: size, height: size }}
    />
  );
}
