/**
 * POST /api/lcie/determine-codes
 * Green G(P)4 Supply Chain Framework — LCIE AI Agent
 *
 * Body: { "poId": string }
 *
 * Runs the LCIE harmonized-code determination AI agent over every line item
 * of the stored Purchase Order, for US (HTS), UK (Global Tariff) and
 * EU (TARIC/CN8). Stores one HsDetermination per (line × region).
 * Returns the determinations plus a step-by-step agent audit trail.
 */

import { NextRequest, NextResponse } from 'next/server';
import { determineHsCodesForPo } from '@/lib/lcie/agent';
import { verifyLicense, consumeLicense } from '@/lib/lcie/license';
import type { ApiError, DetermineResponse } from '@/lib/lcie/types';

export const runtime = 'nodejs';
export const maxDuration = 180;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => ({}));
    const poId = typeof body?.poId === 'string' ? body.poId : '';
    if (!poId) {
      return NextResponse.json<ApiError>({ error: 'poId is required.' }, { status: 400 });
    }

    // ===== License gate (metered) =====
    // The agent run is the billable action. Read the license key from the
    // X-License-Key header (sent by the frontend from localStorage). Verify +
    // consume one calculation; return 402 (Payment Required) if invalid/exhausted
    // so the frontend shows the paywall.
    const licenseKey = req.headers.get('x-license-key') ?? '';
    const license = await verifyLicense(licenseKey);
    if (!license.valid) {
      return NextResponse.json<ApiError & { remaining?: number }>(
        { error: license.reason ?? 'License required.', detail: 'Subscribe via Lemon Squeezy or start a free preview (3 calcs/month).' },
        { status: 402 },
      );
    }
    const consumed = await consumeLicense(licenseKey, 'determine', { poId });
    if (!consumed.valid) {
      return NextResponse.json<ApiError & { remaining?: number }>(
        { error: consumed.reason ?? 'Monthly quota exhausted.', detail: 'Upgrade to continue — your free-preview quota is used up.' },
        { status: 402 },
      );
    }

    const result: DetermineResponse = await determineHsCodesForPo(poId);
    // attach license usage to the response so the UI can show remaining quota
    (result as DetermineResponse & { license?: unknown }).license = {
      plan: consumed.plan, used: consumed.usedCount, remaining: consumed.remaining, cap: consumed.monthlyCap,
    };
    return NextResponse.json(result, { status: 200 });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json<ApiError>({ error: 'LCIE agent failed.', detail: message }, { status: 500 });
  }
}
